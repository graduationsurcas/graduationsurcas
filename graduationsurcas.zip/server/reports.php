<?php

define("ADDNEWPLACE", "Admin inserted new place");
define("UPDATEITEM", "Admin update item");
define("UPDATEPLACE", "Admin update place");
define("REMOVEPLCAE", "Admin delete place");
define("REMOVEITEM", "Admin delete item");
define("ADDNEWITEM", "Admin inserted new item");
define("UPDATESERVICEPROVIDER", "Admin updated services provider");
define("REMOVESERVICEPROVIDER", "Admin removed services provider");
define("UPDATESERVICEPROVIDERPASS", "Admin updated services provider password");
define("ADDNEWADMIN", "New Addmin Added");

