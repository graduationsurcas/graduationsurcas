<div class="container">
    <div class="row vertical-offset-100">
        <div id="login-form" class="col-md-4 col-md-offset-4">
            <div class="panel panel-default" >
                <div class="panel-heading">                                
                    <div class="row-fluid user-row">
                        <img class="center-content img-responsive" alt="oman map" 
                             src="images/iconmap.png"

                             />
                    </div>
                </div>
                <div class="panel-body">
                    <form accept-charset="UTF-8" method="POST" role="form" id="form-forgetpassword">
                        <fieldset>
                            <center>
                                <label id="login_result">

                                </label>
                            </center>
                            <div class="input-group">
                                    <div class="input-group-addon"><span>@&nbsp;</span>Email</div>
                                    <input class="form-control" placeholder="email" required="" name="useremail" id="useremail" type="email">
                                
                            </div>

                            <input class="btn  btn-success btn-block" type="submit" id="password" value="Get Password">

                            <hr>

                            <span class="pull-right">
                                <a href="index.php">Sing in</a>
                            </span>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
