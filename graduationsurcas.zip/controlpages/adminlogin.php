<div class="container">
    <div class="row vertical-offset-100">
        <div id="login-form" class="col-md-4 col-md-offset-4">
            <div class="panel panel-default" >
                <div class="panel-heading">                                
                    <div class="row-fluid user-row">
                        <img class="center-content img-responsive" alt="oman map" 
                             src="../images/admin.png"

                             />
                        Please Login before access Administration Panel 
                    </div>
                </div>
                <div class="panel-body">
                    <form accept-charset="UTF-8" method="POST" role="form" id="form-root-admin-signin">
                        <fieldset>
                            <center>
                                <label id="login_result">

                                </label>
                            </center>
                            <div class="input-group">
                                    <div class="input-group-addon"><span>@&nbsp;</span>Email</div>
                                    <input class="form-control" placeholder="email" required="" name="useremail" id="useremail" type="email">
                                
                            </div>

                            <div class="input-group">
                                <div class="input-group-addon" ><span class="fa fa-lock">&nbsp;</span>Password</div>
                                <input class="form-control" placeholder="Password" required="" name="userpassword" id="userpassword" type="password">
                            </div>


                            <input class="btn  btn-success btn-block" type="submit" id="login" value="Login">

                            <hr>

                            <span class="pull-right">
                                <a href="../forgetPassword.php">forgot password</a>
                            </span>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
