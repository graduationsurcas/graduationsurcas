

<?php
include './QRcreator.php';
?>
<a download href="http://localhost/graduationsurcas/qr/QRcreator.php?qrdata=gheith&save=true&qrtitle=oman">download</a>
<img src="<?php echo 'http://localhost/graduationsurcas/qr/QRcreator.php?qrdata=gheith'; ?>"/>