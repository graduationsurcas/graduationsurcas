<?php

define("SHARE_PLACE", "#oman");
