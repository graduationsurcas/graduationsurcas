<!DOCTYPE html>
<html>
    <head>
        <?php
            include_once 'include/headerlink.html';
        ?>
        <link href="css/forgetpassword.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>


        <?php
        include_once 'controlpages/forgetpassword.php';
        ?>


        <?php
            include_once 'include/fotterlink.html';
        ?>
    </body>
</html>