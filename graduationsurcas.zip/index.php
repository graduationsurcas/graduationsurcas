<!DOCTYPE html>
<html>
    <head>
        <?php
            include_once 'include/headerlink.html';
        ?>
        <link href="css/login.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>


        <?php
        include_once 'controlpages/login.php';
        ?>

        <?php
            include_once 'include/fotterlink.html';
        ?>
    </body>
</html>
