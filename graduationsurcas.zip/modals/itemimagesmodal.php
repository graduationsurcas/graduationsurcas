<!-- Modal -->
<div class="modal fade" id="item_images_modal" tabindex="-1" role="dialog" aria-labelledby="item_images_modal_Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="item_images_modal_Label">
                    <i class="fa fa-image"></i>&nbsp;Items Image/'s
                </h4>
            </div>
            <div class="modal-body">
                <div id="item_images_modal_body_info">
                    <div class="carousel slide article-slide" id="article-photo-carousel">

                        <!-- Wrapper for slides -->
                        <div id="item_images_place" class="carousel-inner cont-slider">

                            

                        </div>
                       

                    </div>
                </div>
                <div>
                     <!-- Indicators -->
                            <ol  class="carousel-indicators">
                               


                            </ol>
                </div>
            </div>
            <div class="modal-footer">
                
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>



